# jardrobe – Umgesetzte Änderungen (Block A)

Gegenüber der letzten hochgeladenen Version:

✓ Linien/Rahmen jetzt GERADE (Wackel-Effekt raus)
✓ Likes/Wunschliste entfernt (kommt später mit Account-Sinn zurück)
✓ Suche komplett raus (Navigation + Seite)
✓ Kategorie-Spalte: schmaler, Schriftzüge von unten nach oben lesbar
✓ Mobil: Footer kompakter
✓ "Bitte Größe wählen" raus – Button bleibt einfach inaktiv
✓ Aktive Auswahl-Buttons (Größe/Farbe) in Theme-Akzentfarbe (rot/orange/lila)
✓ Shop-Schriftzug anklickbar (Link zum Shop) mit mehr Abstand
✓ Logo auf Produktseite kleiner
✓ VIER Theme-Modi: Hell (rot/weiß) → Dunkel → Orange/Creme → Lila/Creme
  (durchschalten mit dem Theme-Knopf; du wählst welche bleiben)
✓ Beutel als neue Kategorie + Platzhalter-Produkt
✓ Lookbook: große Foto-Kacheln (rote Rahmen), Platzhalter bis echte Fotos da sind
✓ Vorbestell-Aktion: Button "Vorbestellen" + Hinweis "Versand ab 01.08.2026"
  (in config.js unter "preorder" an/aus + Datum änderbar)
✓ Size-Reference: Text pro Galeriebild beim Durchswipen möglich
  (Beispiel beim Rotwein-Shirt: "Fio ist 175 und trägt M")

## Hochladen
Wie immer: Inhalt des Ordners per FileZilla nach public_html, vorhandene
Dateien überschreiben. Danach jardrobe.de mit Strg+F5 neu laden.

## Was noch auf DEIN Material wartet (Block B/C)
- Eigene Font(s), Favicon, Herz-SVG (für später), Beutel-Kategorie-Schriftzug
- Logo-Varianten mit weißem Schatten für Dunkelmodus
- Korrigierte Produktfoto-SVGs (falls weiße Linien stören)
- Mockup für äußere Rahmen-Abstände
- Texte: Über-Seite, Produkttexte, Shirt-Titel-Formulierungen
- Entscheidungen: Damen/Herren, "Andere Designs" behalten?, Journal behalten?

## Themes anpassen
In config.js bei "themes" die Farben ändern, bei "themeOrder" die
Reihenfolge/Auswahl. Willst du z.B. nur Hell+Dunkel: themeOrder auf
["hell","dunkel"] kürzen.

---
# Update: Font, Favicon, Beutel-Produkte, Logo-Dunkelvariante

✓ Eigene Font "JanzEinfach" eingebaut (überall außer Produkttitel + SVGs)
  - Produkttitel in den Kästen bleiben Bebas Neue (wie gewünscht)
  - Font liegt als css/janzeinfach.woff2 (aus deiner .otf konvertiert)
✓ Favicon (Bügel) in allen Seiten – erscheint im Browser-Tab
  - img/favicon.svg (ohne Hintergrund) ist aktiv
  - img/favicon-bg.svg (mit weißem Hintergrund) liegt als Alternative bereit
✓ Logo-Dunkelvariante: im Dunkelmodus wechselt das Logo automatisch
  auf img/logo-dunkel.svg (weißer Schatten bleibt sichtbar)
✓ Beutel-Kategorie-Schriftzug aktiv (deine Handschrift)
✓ 5 echte Beutel-Produkte mit Fotos (je 9,00 €):
  Rotwein, Weißwein, Pupe, Hammer&Sichel, Marx&Lenin

## Hochladen
Diesmal sind NEUE Dateien dabei (Font, Favicon, Beutel-SVGs, Logo-dunkel).
Am sichersten: kompletten Ordner-Inhalt neu hochladen, alles überschreiben.
Wichtig: der Ordner css/ enthält jetzt auch janzeinfach.woff2 – muss mit hoch!
