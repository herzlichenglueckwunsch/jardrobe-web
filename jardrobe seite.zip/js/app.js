/* =====================================================================
   JARDROBE v3 – APP LOGIK
   Du musst hier normal NICHTS ändern. Alles Anpassbare = config.js.
   ===================================================================== */

const STORE = {
  getTheme(){ return localStorage.getItem("jd_theme") || CONFIG.defaults.theme; },
  setTheme(t){ localStorage.setItem("jd_theme", t); },
  getView(){ return localStorage.getItem("jd_view") || CONFIG.defaults.view; },
  setView(v){ localStorage.setItem("jd_view", v); },
};

/* ---- Theme: 4 Modi durchschalten ---- */
function applyTheme(){
  let name = STORE.getTheme();
  if (!CONFIG.themes[name]) name = CONFIG.themeOrder[0];
  const t = CONFIG.themes[name];
  const r = document.documentElement.style;
  r.setProperty("--rot", t.akzent);   // --rot ist die aktive Akzentfarbe des Themes
  r.setProperty("--bg", t.bg);
  r.setProperty("--text", t.text);
  r.setProperty("--muted", t.muted);
  r.setProperty("--card", t.card);
  r.setProperty("--shadow", t.shadow);
  // Knopf zeigt das NÄCHSTE Theme an
  const order = CONFIG.themeOrder;
  const next = order[(order.indexOf(name)+1) % order.length];
  const tb = document.querySelector("[data-theme-toggle]");
  if (tb) tb.textContent = CONFIG.themes[next].label;
  // Logo ggf. auf Dunkel-Variante umstellen
  if (typeof renderLogo === "function") renderLogo();
}
function toggleTheme(){
  const order = CONFIG.themeOrder;
  let cur = STORE.getTheme();
  if (!CONFIG.themes[cur]) cur = order[0];
  const next = order[(order.indexOf(cur)+1) % order.length];
  STORE.setTheme(next); applyTheme();
}

/* ---- Hilfen ---- */
function findProduct(id){ return CONFIG.products.find(p=>p.id===id); }
function priceStr(p){ return p.price.toFixed(2).replace(".",",")+" "+CONFIG.currencySymbol; }
function absUrl(path){ return new URL(path, window.location.href).href; }
/* Wunschliste/Likes: vorerst entfernt (kommt später mit Account-Sinn zurück). */

/* ---- Logo (SVG) + Shop-Schriftzug (anklickbar), oben rechts ---- */
function currentLogoFile(){
  const dark = STORE.getTheme()==="dunkel";
  return (dark && CONFIG.logo.fileDunkel) ? CONFIG.logo.fileDunkel : CONFIG.logo.file;
}
function renderLogo(){
  const el = document.querySelector("[data-logo]");
  if (!el) return;
  const shop = CONFIG.shopSchriftzug
    ? `<a class="shop-link" href="index.html" aria-label="Zum Shop"><img class="shop-schriftzug" src="${CONFIG.shopSchriftzug}" alt="Shop"></a>` : "";
  el.innerHTML = `<img class="logo-img" src="${currentLogoFile()}" alt="${CONFIG.logo.alt}" style="width:${CONFIG.logo.width}px;max-width:100%;">${shop}`;
}
function renderTopnav(activeFile){
  const el=document.querySelector("[data-topnav]"); if(!el) return;
  el.innerHTML = CONFIG.nav.map(n=>{
    const active = activeFile && n.href.split("?")[0]===activeFile ? "active":"";
    return `<a href="${n.href}" class="${active}">${n.label}</a>`;
  }).join("");
}
function renderCatRail(activeId){
  const el=document.querySelector("[data-catrail]"); if(!el) return;
  el.innerHTML = CONFIG.categories.map(c=>{
    const inner = c.schriftzug
      ? `<img class="cat-sz" src="${c.schriftzug}" alt="${c.label}">`
      : c.label;
    return `<a href="category.html?cat=${c.id}" class="${c.id===activeId?"active":""}" title="${c.label}">${inner}</a>`;
  }).join("");
}
function renderFooter(){
  const el=document.querySelector("[data-footer]"); if(!el) return;
  el.innerHTML = CONFIG.footerLinks.map(l=>{
    const inner = l.schriftzug
      ? `<img class="foot-sz" src="${l.schriftzug}" alt="${l.label}">`
      : l.label;
    return `<a href="page.html?p=${l.page}" title="${l.label}">${inner}</a>`;
  }).join("");
}

/* Produktkarte */
function cardHTML(p){
  const img=p.colors[0]?p.colors[0].image:"";
  return `<a class="card sketch" href="product.html?id=${p.id}">
    ${p.new?`<span class="badge">neu</span>`:""}
    <div class="img">${img?`<img src="${img}" alt="${p.name}">`:`<div class="ph-empty"></div>`}</div>
    <div class="cap"><span class="nm">${p.name}</span><span class="pr">${priceStr(p)}</span></div>
  </a>`;
}
function wireCardWish(){ /* entfällt – Likes vorerst raus */ }

/* View grid/list */
function applyView(){
  const grid=document.querySelector("[data-products]"); if(!grid) return;
  const v=STORE.getView();
  grid.classList.toggle("list", v==="list");
  document.querySelectorAll("[data-view-btn]").forEach(b=>b.classList.toggle("active",b.dataset.viewBtn===v));
}
function wireViewSwitch(){
  document.querySelectorAll("[data-view-btn]").forEach(b=>b.addEventListener("click",()=>{STORE.setView(b.dataset.viewBtn);applyView();}));
}

/* ===== Sidebar (nur Warenkorb) ===== */
function buildSidebar(){
  if(document.querySelector(".sb")) return;
  const w=document.createElement("div");
  w.innerHTML=`
    <div class="sb-back" data-back></div>
    <aside class="sb" data-sb aria-hidden="true">
      <div class="sb-head"><h3>Warenkorb</h3><button class="x" data-sb-close>×</button></div>
      <div class="sb-body" data-sb-body></div>
      <div class="sb-foot" data-sb-foot></div>
    </aside>`;
  document.body.appendChild(w);
  document.querySelector("[data-back]").addEventListener("click",closeSidebar);
  document.querySelector("[data-sb-close]").addEventListener("click",closeSidebar);
}
function openSidebar(){ buildSidebar(); renderCartSidebar();
  document.querySelector("[data-sb]").classList.add("open"); document.querySelector("[data-back]").classList.add("open"); }
function closeSidebar(){ document.querySelector("[data-sb]")?.classList.remove("open"); document.querySelector("[data-back]")?.classList.remove("open"); }
function renderCartSidebar(){
  const body=document.querySelector("[data-sb-body]"); const foot=document.querySelector("[data-sb-foot]");
  if(!body)return;
  if(!window.Snipcart){ body.innerHTML=`<p class="empty">Warenkorb lädt …<br>(Snipcart-Key in config.js eintragen)</p>`; foot.innerHTML=`<button class="co snipcart-checkout">Zur Kasse</button>`; return; }
  const cart=window.Snipcart.store.getState().cart; const items=cart.items.items||[];
  if(!items.length){ body.innerHTML=`<p class="empty">Warenkorb ist leer.</p>`; foot.innerHTML=""; return; }
  body.innerHTML=items.map(it=>`<div class="mini"><img src="${it.image||""}" alt=""><div><div class="mn">${it.name}</div><div class="ms">${it.quantity} × ${it.price.toFixed(2).replace(".",",")} ${CONFIG.currencySymbol}</div></div><div class="ma"></div></div>`).join("");
  foot.innerHTML=`<button class="co snipcart-checkout">Zur Kasse · ${cart.total.toFixed(2).replace(".",",")} ${CONFIG.currencySymbol}</button>`;
}
function wireTopbar(){
  document.querySelector("[data-open-cart]")?.addEventListener("click",()=>openSidebar());
  document.querySelector("[data-theme-toggle]")?.addEventListener("click",toggleTheme);
}

/* ===== Seiten ===== */
function renderHome(){
  const grid=document.querySelector("[data-home]"); if(!grid)return;
  grid.innerHTML=CONFIG.products.filter(p=>p.featured).map(cardHTML).join("");
  applyView();
}
function renderCategory(){
  const grid=document.querySelector("[data-category]"); if(!grid)return;
  const catId=new URLSearchParams(location.search).get("cat");
  const cat=CONFIG.categories.find(c=>c.id===catId);
  const t=document.querySelector("[data-cat-title]"); if(t)t.textContent=cat?cat.label:"Kategorie";
  renderCatRail(catId);
  const items=CONFIG.products.filter(p=>p.category===catId);
  grid.innerHTML=items.length?items.map(cardHTML).join(""):`<p>Hier ist noch nichts. Bald mehr.</p>`;
  applyView();
}

const pstate={product:null,size:null,color:null,qty:1,slide:0};
function galleryImages(p){
  // gallery aus config, sonst Fallback auf die Farbbilder
  if (p.gallery && p.gallery.length) return p.gallery.slice();
  return p.colors.map(c=>c.image);
}
function renderProduct(){
  const root=document.querySelector("[data-product]"); if(!root)return;
  const id=new URLSearchParams(location.search).get("id");
  const p=findProduct(id);
  if(!p){ root.innerHTML="<p>Produkt nicht gefunden.</p>"; return; }
  pstate.product=p; pstate.color=p.colors[0]||null; pstate.size=null; pstate.qty=1; pstate.slide=0;
  renderCatRail(p.category);

  const gal = galleryImages(p);
  const caps = p.captions || [];

  const sib=CONFIG.products.filter(x=>x.category===p.category&&x.id!==p.id);
  const strip = sib.length?`<div class="variants"><span class="flabel">Andere Designs</span><div class="vstrip">
    ${sib.map(s=>`<a href="product.html?id=${s.id}" title="${s.name}"><img src="${s.colors[0]?s.colors[0].image:""}" alt="${s.name}"></a>`).join("")}
    </div></div>`:"";

  const pre = CONFIG.preorder && CONFIG.preorder.aktiv;
  const addLabel = pre ? (CONFIG.preorder.buttonText||"Vorbestellen") : "In den Korb";
  const preNote = pre ? `<div class="preorder-note">${CONFIG.preorder.hinweis||""}</div>` : "";

  root.innerHTML=`<div class="detail">
    <div class="gallery-wrap">
      <div class="gallery sketch">
        <button class="gnav prev" data-gprev aria-label="Vorheriges Bild">‹</button>
        <div class="img"><img data-main alt="${p.name}"></div>
        <div class="gcaption" data-gcaption></div>
        <button class="gnav next" data-gnext aria-label="Nächstes Bild">›</button>
      </div>
      <div class="thumbs" data-thumbs></div>
    </div>
    <div class="info">
      <div class="title">${p.name}</div>
      <div class="price">${priceStr(p)}</div>
      <p class="desc">${p.description||""}</p>
      ${preNote}
      ${p.colors.length>1?`<div class="field"><span class="flabel">Farbe</span><div class="choices">
        ${p.colors.map((c,i)=>`<button class="choice ${i===0?"selected":""}" data-color="${i}">${c.name}</button>`).join("")}</div></div>`:""}
      ${p.sizes.length?`<div class="field"><span class="flabel">Größe</span><div class="choices">
        ${p.sizes.map(s=>`<button class="choice" data-size="${s}">${s}</button>`).join("")}</div></div>`:""}
      <div class="field"><span class="flabel">Menge</span>
        <div class="qty"><button data-qminus>−</button><input data-qinput value="1" readonly><button data-qplus>+</button></div></div>
      <div class="addrow">
        <button class="add snipcart-add-item" data-add ${p.sizes.length?"disabled":""}>${addLabel}</button>
      </div>
      ${strip}
    </div></div>`;

  /* ----- Galerie aufbauen + Swipe ----- */
  const main = root.querySelector("[data-main]");
  const thumbs = root.querySelector("[data-thumbs]");
  const capEl = root.querySelector("[data-gcaption]");
  thumbs.innerHTML = gal.map((src,i)=>
    `<button class="thumb ${i===0?"active":""} ${src?"":"empty"}" data-slide="${i}" aria-label="Bild ${i+1}">
       ${src?`<img src="${src}" alt="">`:""}
     </button>`).join("");

  function showSlide(i){
    pstate.slide = (i + gal.length) % gal.length;
    const src = gal[pstate.slide];
    if (src){ main.style.visibility="visible"; main.src = src; }
    else { main.removeAttribute("src"); main.style.visibility="hidden"; }
    // Size-Reference / Bildunterschrift
    const cap = caps[pstate.slide] || "";
    capEl.textContent = cap; capEl.style.display = cap ? "block" : "none";
    thumbs.querySelectorAll(".thumb").forEach((t,idx)=>t.classList.toggle("active",idx===pstate.slide));
  }
  thumbs.querySelectorAll("[data-slide]").forEach(t=>t.addEventListener("click",()=>showSlide(+t.dataset.slide)));
  root.querySelector("[data-gprev]").addEventListener("click",()=>showSlide(pstate.slide-1));
  root.querySelector("[data-gnext]").addEventListener("click",()=>showSlide(pstate.slide+1));

  const galEl = root.querySelector(".gallery");
  let tx=0;
  galEl.addEventListener("touchstart",e=>{ tx=e.changedTouches[0].clientX; },{passive:true});
  galEl.addEventListener("touchend",e=>{
    const dx=e.changedTouches[0].clientX-tx;
    if(Math.abs(dx)>40) showSlide(pstate.slide + (dx<0?1:-1));
  },{passive:true});

  showSlide(0);

  /* ----- Optionen ----- */
  root.querySelectorAll("[data-color]").forEach(b=>b.addEventListener("click",()=>{
    root.querySelectorAll("[data-color]").forEach(x=>x.classList.remove("selected")); b.classList.add("selected");
    pstate.color=p.colors[+b.dataset.color];
    if(pstate.color.image){ gal[0]=pstate.color.image; showSlide(0); thumbs.querySelector(".thumb")?.querySelector("img")?.setAttribute("src",pstate.color.image); }
    updateAdd();
  }));
  root.querySelectorAll("[data-size]").forEach(b=>b.addEventListener("click",()=>{
    root.querySelectorAll("[data-size]").forEach(x=>x.classList.remove("selected")); b.classList.add("selected");
    pstate.size=b.dataset.size; updateAdd();
  }));
  root.querySelector("[data-qminus]")?.addEventListener("click",()=>setQty(pstate.qty-1));
  root.querySelector("[data-qplus]")?.addEventListener("click",()=>setQty(pstate.qty+1));
  updateAdd();
}
function setQty(n){ pstate.qty=Math.max(1,n); document.querySelector("[data-qinput]").value=pstate.qty; updateAdd(); }
function updateAdd(){
  const btn=document.querySelector("[data-add]"); if(!btn)return;
  const p=pstate.product; const needs=p.sizes.length>0; const ready=!needs||pstate.size;
  btn.disabled=!ready;
  const vid=`${p.id}__${pstate.color?pstate.color.name:"std"}${pstate.size?"__"+pstate.size:""}`;
  btn.setAttribute("data-item-id",vid);
  btn.setAttribute("data-item-price",p.price.toFixed(2));
  btn.setAttribute("data-item-url",absUrl("product.html?id="+p.id));
  btn.setAttribute("data-item-name",p.name);
  btn.setAttribute("data-item-image",absUrl(pstate.color?pstate.color.image:""));
  btn.setAttribute("data-item-quantity",pstate.qty);
  let i=1;
  if(pstate.color){ btn.setAttribute(`data-item-custom${i}-name`,"Farbe"); btn.setAttribute(`data-item-custom${i}-value`,pstate.color.name); i++; }
  if(pstate.size){ btn.setAttribute(`data-item-custom${i}-name`,"Größe"); btn.setAttribute(`data-item-custom${i}-value`,pstate.size); i++; }
  if(CONFIG.preorder && CONFIG.preorder.aktiv){ btn.setAttribute(`data-item-custom${i}-name`,"Vorbestellung"); btn.setAttribute(`data-item-custom${i}-value`,"Versand ab 01.08.2026"); }
}


function renderLookbook(){
  const root=document.querySelector("[data-lookbook]"); if(!root)return;
  const items = (CONFIG.lookbook && CONFIG.lookbook.length) ? CONFIG.lookbook : [{},{},{},{}];
  root.innerHTML=`<div class="lookbook">`+items.map(l=>{
    const link=l.productId?`<a class="sl" href="product.html?id=${l.productId}">shop →</a>`:"";
    const inner = l.image
      ? `<img src="${l.image}" alt="${l.caption||""}">`
      : `<div class="lb-empty">Foto folgt</div>`;
    return `<figure class="look sketch"><div class="lb-img">${inner}</div><figcaption class="cap"><span>${l.caption||""}</span>${link}</figcaption></figure>`;
  }).join("")+`</div>`;
}

function routeJournal(){
  const id=new URLSearchParams(location.search).get("id");
  const listEl=document.querySelector("[data-journal-list]"); const fullEl=document.querySelector("[data-journal-full]");
  if(!listEl||!fullEl)return;
  if(id){ listEl.style.display="none"; fullEl.style.display="block"; } else { listEl.style.display="block"; fullEl.style.display="none"; }
}
function renderJournal(){
  const list=document.querySelector("[data-journal-list]");
  if(list) list.innerHTML=`<div class="journal">`+CONFIG.journal.map(j=>`<article class="jentry"><div class="date">${j.date}</div><h2>${j.title}</h2><p>${j.teaser}</p><a class="more" href="journal.html?id=${j.id}">weiterlesen →</a></article>`).join("")+`</div>`;
  const full=document.querySelector("[data-journal-full]");
  if(full){ const id=new URLSearchParams(location.search).get("id"); const j=CONFIG.journal.find(x=>x.id===id);
    full.innerHTML=j?`<div class="jfull"><a class="more" href="journal.html">← Journal</a><h1>${j.title}</h1><div class="date">${j.date}</div><p>${j.body}</p></div>`:""; }
}

function renderCartPage(){
  const root=document.querySelector("[data-cartpage]"); if(!root)return;
  function draw(){
    if(!window.Snipcart){ root.innerHTML=`<h1>Warenkorb</h1><p>Lädt … Wenn das bleibt, fehlt der Snipcart-Key in config.js.</p>`; return; }
    const cart=window.Snipcart.store.getState().cart; const items=cart.items.items||[];
    if(!items.length){ root.innerHTML=`<h1>Warenkorb</h1><p>Dein Warenkorb ist leer.</p><p><a class="more" href="index.html" style="color:var(--rot)">← weiter shoppen</a></p>`; return; }
    root.innerHTML=`<h1>Warenkorb</h1>`+items.map(it=>`<div class="cline"><img src="${it.image||""}" alt=""><div><strong>${it.name}</strong><br><span style="color:var(--muted)">${it.quantity} × ${it.price.toFixed(2).replace(".",",")} ${CONFIG.currencySymbol}</span></div><div>${(it.price*it.quantity).toFixed(2).replace(".",",")} ${CONFIG.currencySymbol}</div></div>`).join("")+`<div class="ctotal"><span>Summe</span><span>${cart.total.toFixed(2).replace(".",",")} ${CONFIG.currencySymbol}</span></div><div style="margin-top:18px"><button class="add snipcart-checkout">Zur Kasse</button></div>`;
  }
  draw();
  document.addEventListener("snipcart.ready",()=>{ draw(); window.Snipcart.store.subscribe(draw); });
}

function renderTextPage(){
  const root=document.querySelector("[data-textpage]"); if(!root)return;
  const key=new URLSearchParams(location.search).get("p");
  const link=CONFIG.footerLinks.find(l=>l.page===key)||CONFIG.nav.find(n=>n.href.includes("p="+key));
  const title=link?link.label:(key||"Seite");
  const text=CONFIG.pageContent[key]||"Noch kein Inhalt.";
  root.innerHTML=`<h1>${title}</h1><p>${text.replace(/\n/g,"</p><p>")}</p>`;
}

function injectSnipcart(){ const el=document.getElementById("snipcart"); if(el)el.setAttribute("data-api-key-only",CONFIG.snipcartKey); }

/* ===== INIT ===== */
document.addEventListener("DOMContentLoaded",()=>{
  injectSnipcart(); applyTheme();
  renderLogo();
  renderTopnav(location.pathname.split("/").pop());
  renderCatRail(null); renderFooter(); wireTopbar(); wireViewSwitch();
  renderHome(); renderCategory(); renderProduct();
  renderLookbook(); routeJournal(); renderJournal(); renderCartPage(); renderTextPage();
});
document.addEventListener("snipcart.ready",()=>{
  const refresh=()=>{ const cart=window.Snipcart.store.getState().cart;
    document.querySelectorAll("[data-cart-count]").forEach(el=>el.textContent=cart.items.count||0);
    if(document.querySelector(".sb.open"))renderCartSidebar(); };
  refresh(); window.Snipcart.store.subscribe(refresh);
});
