/* Generiert vom jardrobe Manager. Nicht von Hand editieren, wenn du das Tool nutzt. */
const CONFIG = {
  shopName: "jardrobe",
  currency: "EUR",
  currencySymbol: "€",
  tagline: "",
  snipcartKey: "DEIN_SNIPCART_PUBLIC_KEY_HIER",
  preorder: {
    aktiv: true,
    buttonText: "Vorbestellen",
    hinweis: "Vorbestellung – Versand ab 01.08.2026. Du zahlst jetzt, wir verschicken gesammelt zum Termin."
  },
  logo: {
    file: "img/logo.svg",
    fileDunkel: "img/logo-dunkel.svg",
    width: 300,
    alt: "jardrobe"
  },
  shopSchriftzug: "img/shop-schriftzug.svg",
  defaults: {
    theme: "hell",
    view: "grid"
  },
  themeOrder: [ "hell", "dunkel", "orange", "lila" ],
  themes: {
    hell: {
      label: "Hell",
      akzent: "#e30613",
      bg: "#ffffff",
      text: "#121212",
      muted: "#666666",
      card: "#ffffff",
      shadow: "#121212"
    },
    dunkel: {
      label: "Dunkel",
      akzent: "#e30613",
      bg: "#0e0e0e",
      text: "#f2f2f2",
      muted: "#9a9a9a",
      card: "#1a1a1a",
      shadow: "#000000"
    },
    orange: {
      label: "Orange",
      akzent: "#e8771a",
      bg: "#f6f1e7",
      text: "#2a2118",
      muted: "#7a6f5e",
      card: "#fffdf8",
      shadow: "#c9b89a"
    },
    lila: {
      label: "Lila",
      akzent: "#7b3fa0",
      bg: "#f4f0f6",
      text: "#241a2b",
      muted: "#6f5e7a",
      card: "#fdfaff",
      shadow: "#bda9c9"
    }
  },
  categories: [
    {
      id: "tshirts",
      label: "T-Shirts",
      schriftzug: "img/schriftzuege/tshirts.svg"
    },
    {
      id: "pullis",
      label: "Pullis",
      schriftzug: "img/schriftzuege/pullis.svg"
    },
    {
      id: "beutel",
      label: "Beutel",
      schriftzug: "img/schriftzuege/beutel.svg"
    },
    {
      id: "firlefanz",
      label: "Firlefanz",
      schriftzug: "img/schriftzuege/firlefanz.svg"
    },
    {
      id: "poster",
      label: "Poster",
      schriftzug: "img/schriftzuege/poster.svg"
    },
    {
      id: "sticker",
      label: "Sticker",
      schriftzug: "img/schriftzuege/sticker.svg"
    }
  ],
  nav: [
    {
      label: "Shop",
      href: "index.html"
    },
    {
      label: "Lookbook",
      href: "lookbook.html"
    },
    {
      label: "Journal",
      href: "journal.html"
    },
    {
      label: "Über",
      href: "page.html?p=ueber"
    }
  ],
  footerLinks: [
    {
      label: "Impressum",
      page: "impressum",
      schriftzug: "img/schriftzuege/impressum.svg"
    },
    {
      label: "Kontakt",
      page: "kontakt",
      schriftzug: "img/schriftzuege/kontakt.svg"
    },
    {
      label: "Versand & Rücksendung",
      page: "versand",
      schriftzug: "img/schriftzuege/versand.svg"
    },
    {
      label: "AGB",
      page: "agb",
      schriftzug: "img/schriftzuege/agb.svg"
    }
  ],
  products: [
    {
      id: "lieber-rotwein",
      name: "Lieber Rotwein als tot sein",
      category: "tshirts",
      price: 24.9,
      description: "Hochwertiges Shirt, im Siebdruck gedruckt. Klassiker für jede Lebenslage.",
      sizes: [ "S", "M", "L", "XL" ],
      colors: [
        {
          name: "Blau",
          image: "img/produktfotos/rotwein-blau.svg"
        }
      ],
      gallery: [ "img/produktfotos/rotwein-blau.svg", "img/designs/rotwein.svg", "", "" ],
      captions: [ "", "", "Fio ist 175 und trägt M", "Luisa ist knapp über 175 und trägt auch M" ],
      featured: true,
      new: true,
      tags: [ "wein", "rotwein", "spruch", "blau" ]
    },
    {
      id: "lieber-weisswein",
      name: "Lieber Weißwein",
      category: "tshirts",
      price: 24.9,
      description: "Für die hellere Stimmung. Siebdruck auf grünem Shirt.",
      sizes: [ "S", "M", "L", "XL" ],
      colors: [
        {
          name: "Grün",
          image: "img/produktfotos/weisswein-gruen.svg"
        }
      ],
      gallery: [ "img/produktfotos/weisswein-gruen.svg", "img/designs/weisswein.svg", "", "" ],
      featured: true,
      new: false,
      tags: [ "wein", "weisswein", "spruch", "grün" ]
    },
    {
      id: "pupe-schmatzen",
      name: "Kannst mir anne Pupe schmatzen",
      category: "tshirts",
      price: 25,
      description: "arschjeleckt bonanza",
      sizes: [ "S", "M", "L", "XL" ],
      colors: [
        {
          name: "Weiß",
          image: "img/produktfotos/pupe-weiss.svg"
        }
      ],
      gallery: [ "img/produktfotos/pupe-weiss.svg", "img/designs/pupe.svg", "", "" ],
      captions: [ "" ],
      featured: true,
      new: false,
      tags: [ "berlin", "pupe", "schmatzen", "spruch", "weiß" ]
    },
    {
      id: "marxlenin",
      name: "Marx & Lenin",
      category: "tshirts",
      price: 24.9,
      description: "Siebdruck auf rotem Shirt.",
      sizes: [ "S", "M", "L", "XL" ],
      colors: [
        {
          name: "Rot",
          image: "img/produktfotos/marxlenin-rot.svg"
        }
      ],
      gallery: [ "img/produktfotos/marxlenin-rot.svg", "img/designs/marxlenin.svg", "img/designs/marxlenin2.svg", "" ],
      featured: true,
      new: true,
      tags: [ "marx", "lenin", "rot", "politik" ]
    },
    {
      id: "hammer-sichel",
      name: "Hammer & Sichel",
      category: "tshirts",
      price: 24.9,
      description: "Siebdruck auf schwarzem Shirt.",
      sizes: [ "S", "M", "L", "XL" ],
      colors: [
        {
          name: "Schwarz",
          image: "img/produktfotos/hammersichel-schwarz.svg"
        }
      ],
      gallery: [ "img/produktfotos/hammersichel-schwarz.svg", "img/designs/hammersichel.svg", "", "" ],
      featured: true,
      new: false,
      tags: [ "hammer", "sichel", "schwarz", "politik" ]
    },
    {
      id: "poster-1",
      name: "Poster 01",
      category: "poster",
      price: 15,
      description: "Kunstdruck. Platzhalter – echtes Motiv folgt.",
      sizes: [ "A3", "A2" ],
      colors: [
        {
          name: "Standard",
          image: "img/produktfotos/poster-1.svg"
        }
      ],
      gallery: [ "img/produktfotos/poster-1.svg", "img/produktfotos/poster-2.svg", "img/produktfotos/poster-3.svg", "" ],
      featured: false,
      new: false,
      tags: [ "poster", "print" ]
    },
    {
      id: "poster-2",
      name: "Poster 02",
      category: "poster",
      price: 15,
      description: "Kunstdruck. Platzhalter – echtes Motiv folgt.",
      sizes: [ "A3", "A2" ],
      colors: [
        {
          name: "Standard",
          image: "img/produktfotos/poster-4.svg"
        }
      ],
      gallery: [ "img/produktfotos/poster-4.svg", "img/produktfotos/poster-5.svg", "" ],
      featured: false,
      new: false,
      tags: [ "poster", "print" ]
    },
    {
      id: "poster-3",
      name: "Poster 03",
      category: "poster",
      price: 15,
      description: "Kunstdruck. Platzhalter – echtes Motiv folgt.",
      sizes: [ "A3", "A2" ],
      colors: [
        {
          name: "Standard",
          image: "img/produktfotos/poster-6.svg"
        }
      ],
      gallery: [ "img/produktfotos/poster-6.svg", "img/produktfotos/poster-7.svg", "" ],
      featured: false,
      new: false,
      tags: [ "poster", "print" ]
    },
    {
      id: "beutel-rotwein",
      name: "Beutel · Lieber Rotwein",
      category: "beutel",
      price: 9,
      description: "Stoffbeutel mit Siebdruck. Günstiger Begleiter für jeden Tag.",
      sizes: [],
      colors: [
        {
          name: "Natur",
          image: "img/produktfotos/beutel-rotwein.svg"
        }
      ],
      gallery: [ "img/produktfotos/beutel-rotwein.svg", "" ],
      featured: false,
      new: true,
      tags: [ "beutel", "tasche", "rotwein", "wein" ]
    },
    {
      id: "beutel-weisswein",
      name: "Beutel · Lieber Weißwein",
      category: "beutel",
      price: 9,
      description: "Stoffbeutel mit Siebdruck.",
      sizes: [],
      colors: [
        {
          name: "Natur",
          image: "img/produktfotos/beutel-weisswein.svg"
        }
      ],
      gallery: [ "img/produktfotos/beutel-weisswein.svg", "" ],
      featured: false,
      new: false,
      tags: [ "beutel", "tasche", "weisswein", "wein" ]
    },
    {
      id: "beutel-pupe",
      name: "Beutel · Pupe schmatzen",
      category: "beutel",
      price: 9,
      description: "Stoffbeutel mit Siebdruck.",
      sizes: [ "EinsGröße" ],
      colors: [
        {
          name: "Grau",
          image: "img/produktfotos/beutel-pupe.svg"
        }
      ],
      gallery: [ "img/produktfotos/beutel-pupe.svg", "" ],
      captions: [ "" ],
      featured: false,
      new: false,
      tags: [ "beutel", "tasche", "pupe", "berlin" ]
    },
    {
      id: "beutel-hammersichel",
      name: "Beutel · Hammer & Sichel",
      category: "beutel",
      price: 9,
      description: "Stoffbeutel mit Siebdruck, pink auf blau.",
      sizes: [],
      colors: [
        {
          name: "Blau",
          image: "img/produktfotos/beutel-hammersichel.svg"
        }
      ],
      gallery: [ "img/produktfotos/beutel-hammersichel.svg", "" ],
      featured: false,
      new: false,
      tags: [ "beutel", "tasche", "hammer", "sichel", "politik" ]
    },
    {
      id: "beutel-marxlenin",
      name: "Beutel · Marx & Lenin",
      category: "beutel",
      price: 9,
      description: "Stoffbeutel mit Siebdruck, rosa auf schwarz.",
      sizes: [],
      colors: [
        {
          name: "Schwarz",
          image: "img/produktfotos/beutel-marxlenin.svg"
        }
      ],
      gallery: [ "img/produktfotos/beutel-marxlenin.svg", "" ],
      featured: false,
      new: false,
      tags: [ "beutel", "tasche", "marx", "lenin", "politik" ]
    }
  ],
  lookbook: [
    {
      image: "img/produktfotos/rotwein-blau.svg",
      caption: "Lieber Rotwein",
      productId: "lieber-rotwein"
    },
    {
      image: "img/produktfotos/hammersichel-schwarz.svg",
      caption: "Hammern und Sicheln",
      productId: "hammer-sichel"
    },
    {
      image: "img/produktfotos/marxlenin-rot.svg",
      caption: "Marx Lenin",
      productId: "marxlenin"
    },
    {
      image: "img/produktfotos/weisswein-gruen.svg",
      caption: "Lieber Weißwein",
      productId: "lieber-weisswein"
    }
  ],
  journal: [
    {
      id: "launch",
      title: "jardrobe.de ist bald online. wir sind aufer zielgraden das ding hübsch zu machen.",
      date: "2026-07-08",
      teaser: "bald gehts los mit Vorbestellungen.",
      body: "Lange dran jebastelt. bald gehts los."
    },
    {
      id: "siebdruck",
      title: "Wie wa drucken",
      date: "2026-07-08",
      teaser: "Ein Blick in den Druck-Prozess.",
      body: "Jedes Motiv wird einzeln belichtet und von Hand gezogen. Wie ne kleene Manufaktur könnte man meinen."
    }
  ],
  pageContent: {
    ueber: "jardrobe ist ein kleener shop für shirts und pullis und son zeuch. eigene designs, jedruckt in berlin, versand deutschlandweit.",
    impressum: "Benedikt Baumgartl\nSonnenallee 44\n12045  Berlin\nDeutschland\n\nkontakt@jardrobe.de",
    kontakt: "kontakt@jardrobe.de",
    versand: "Wir versenden 2x im Monat. Standardversand innerhalb Deutschlands. Rücksendung innerhalb von 14 Tagen.",
    agb: "Tach, hier die AGB",
    datenschutz: "Und Tach die zweite: hier der Datenschutz"
  }
};
