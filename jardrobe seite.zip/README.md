# jardrobe Shop – handgezeichneter Look (zum Hochladen)

Statische Website (HTML/CSS/JS) + Snipcart fürs Bezahlen. Kein WordPress.
Direkt per FileZilla in `public_html` hochladen.

## Hochladen (FileZilla)
1. Inhalt dieses Ordners (index.html, css/, js/, img/ …) nach `public_html` ziehen.
   NICHT den Ordner selbst – seinen Inhalt.
2. Domain im Browser öffnen – läuft.
   (Warenkorb erst aktiv, wenn Snipcart-Key gesetzt ist, siehe unten.)

## Alles anpassen: js/config.js
Fast alles steht hier. Neu in dieser Version:
- `defaults.wobble` – Stärke des handgezeichneten Wackel-Effekts
  (0 = aus/gerade Linien, 2 = dezent, 5 = krakelig).
- `logo.useImage` – false = Schriftzug "jardrobe" als Logo (Platzhalter).
  Sobald dein echtes Logo als img/logo.png (o.ä.) drin liegt: auf true setzen.

Weiter wie gehabt: Produkte, Kategorien, Farben (Hell/Dunkel), Navigation,
Footer, Lookbook, Journal, Texte – alles in config.js, durchkommentiert.

## Look
- Digitale Struktur + handgezeichnete Details (Wackel-Rahmen via SVG-Filter,
  Caveat-Handschrift für Labels/Footer, Bebas Neue für Überschriften).
- Mobil-first, skaliert sauber auf Desktop.
- Hell/Dunkel umschaltbar, Raster/Liste, Wunschliste, Live-Warenkorb-Sidebar.

## Noch offen (später)
- Dein echtes Logo + echte Produktfotos (aktuell Platzhalter-Shirts).
- Snipcart-Key in config.js (`snipcartKey`).
- Rechtstexte (Impressum/AGB/Datenschutz/Versand) in config.js → pageContent.

## Snipcart kurz
1. Account auf snipcart.com → Dashboard → API Keys.
2. Public-Key in config.js bei `snipcartKey` eintragen.
3. Stripe/PayPal im Snipcart-Dashboard verbinden, Domain hinterlegen.
TEST-Key zum gefahrlosen Durchspielen, LIVE-Key am Launch-Tag.

## Kleinunternehmer §19
Keine MwSt. ausweisen, solange du Kleinunternehmer bist – in Snipcart so einstellen.
